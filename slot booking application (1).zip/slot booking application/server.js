const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  initializeDatabase,
  registerUser,
  authenticateUser,
  listServices,
  listSlots,
  createReservation,
  listBookingsForUser,
  cancelBooking,
  getCurrentUser
} = require('./src/bookingService');

const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, 'public');
const sessions = new Map();

initializeDatabase();

function getSession(req) {
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(cookieHeader.split(';').filter(Boolean).map((entry) => {
    const [name, ...valueParts] = entry.trim().split('=');
    return [name, valueParts.join('=')];
  }));
  const sessionId = cookies['connect.sid'];
  if (!sessionId) {
    return null;
  }
  return sessions.get(sessionId) || null;
}

function createSession(res) {
  const sessionId = crypto.randomBytes(16).toString('hex');
  sessions.set(sessionId, {});
  res.setHeader('Set-Cookie', [`connect.sid=${sessionId}; Path=/; HttpOnly`]);
  return sessionId;
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1e6) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (error) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, payload) {
  const headers = { ...res.getHeaders(), 'Content-Type': 'application/json; charset=utf-8' };
  res.writeHead(statusCode, headers);
  res.end(JSON.stringify(payload));
}

function sendFile(res, filePath, contentType) {
  fs.readFile(filePath, (error, content) => {
    if (error) {
      const headers = { ...res.getHeaders(), 'Content-Type': 'text/plain; charset=utf-8' };
      res.writeHead(404, headers);
      res.end('Not found');
      return;
    }
    const headers = { ...res.getHeaders(), 'Content-Type': contentType };
    res.writeHead(200, headers);
    res.end(content);
  });
}

function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  let session = getSession(req);
  if (!session) {
    session = {};
    const sessionId = createSession(res);
    sessions.set(sessionId, session);
  }

  if (pathname === '/api/health') {
    sendJson(res, 200, { success: true, message: 'KineticAge booking API is running' });
    return;
  }

  if (pathname === '/api/services') {
    sendJson(res, 200, listServices());
    return;
  }

  if (pathname === '/api/slots') {
    sendJson(res, 200, listSlots());
    return;
  }

  if (pathname === '/api/auth/register' && req.method === 'POST') {
    readJsonBody(req).then((body) => {
      const { username, password } = body;
      if (!username || !password) {
        sendJson(res, 400, { error: 'Username and password are required.' });
        return;
      }

      try {
        const user = registerUser(username, password);
        session.userId = user.id;
        sendJson(res, 200, { success: true, user: { id: user.id, username: user.username } });
      } catch (error) {
        sendJson(res, 409, { error: error.message });
      }
    }).catch((error) => sendJson(res, 500, { error: error.message }));
    return;
  }

  if (pathname === '/api/auth/login' && req.method === 'POST') {
    readJsonBody(req).then((body) => {
      const { username, password } = body;
      if (!username || !password) {
        sendJson(res, 400, { error: 'Username and password are required.' });
        return;
      }

      try {
        const user = authenticateUser(username, password);
        session.userId = user.id;
        sendJson(res, 200, { success: true, user: { id: user.id, username: user.username } });
      } catch (error) {
        sendJson(res, 401, { error: error.message });
      }
    }).catch((error) => sendJson(res, 500, { error: error.message }));
    return;
  }

  if (pathname === '/api/auth/logout' && req.method === 'POST') {
    if (session) {
      session.userId = null;
    }
    sendJson(res, 200, { success: true });
    return;
  }

  if (pathname === '/api/auth/me') {
    const user = getCurrentUser(session.userId);
    if (!user) {
      sendJson(res, 401, { error: 'Authentication required.' });
      return;
    }
    sendJson(res, 200, { user });
    return;
  }

  if (pathname === '/api/bookings' && req.method === 'POST') {
    if (!session.userId) {
      sendJson(res, 401, { error: 'Please log in to confirm your reservation.' });
      return;
    }

    readJsonBody(req).then((body) => {
      const { slotId, serviceId, paymentMethod } = body;
      if (!slotId || !serviceId || !paymentMethod) {
        sendJson(res, 400, { error: 'Slot, service, and payment method are required.' });
        return;
      }

      try {
        const booking = createReservation(session.userId, Number(slotId), Number(serviceId), paymentMethod);
        sendJson(res, 201, { success: true, booking });
      } catch (error) {
        sendJson(res, 409, { error: error.message });
      }
    }).catch((error) => sendJson(res, 500, { error: error.message }));
    return;
  }

  if (pathname === '/api/bookings') {
    if (!session.userId) {
      sendJson(res, 401, { error: 'Authentication required.' });
      return;
    }
    sendJson(res, 200, listBookingsForUser(session.userId));
    return;
  }

  if (pathname.startsWith('/api/bookings/') && req.method === 'POST') {
    const bookingId = Number(pathname.split('/').pop());
    if (!session.userId) {
      sendJson(res, 401, { error: 'Authentication required.' });
      return;
    }
    try {
      const booking = cancelBooking(session.userId, bookingId);
      sendJson(res, 200, { success: true, booking });
    } catch (error) {
      sendJson(res, 400, { error: error.message });
    }
    return;
  }

  const filePath = pathname === '/' ? path.join(publicDir, 'index.html') : path.join(publicDir, pathname.replace(/^\//, ''));
  if (filePath.startsWith(publicDir)) {
    const extension = path.extname(filePath);
    const contentType = {
      '.html': 'text/html; charset=utf-8',
      '.css': 'text/css; charset=utf-8',
      '.js': 'application/javascript; charset=utf-8',
      '.json': 'application/json; charset=utf-8',
      '.svg': 'image/svg+xml'
    }[extension] || 'application/octet-stream';
    sendFile(res, filePath, contentType);
    return;
  }

  sendJson(res, 404, { error: 'Not found' });
}

const server = http.createServer(handleRequest);

module.exports = { server };

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`KineticAge booking app is running on http://localhost:${PORT}`);
  });
}
