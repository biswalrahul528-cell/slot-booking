const slotList = document.getElementById('slot-list');
const serviceSelect = document.getElementById('service-select');
const authForm = document.getElementById('auth-form');
const bookingForm = document.getElementById('booking-form');
const bookingMessage = document.getElementById('booking-message');
const authStatus = document.getElementById('auth-status');
const toggleAuth = document.getElementById('toggle-auth');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const bookingDashboard = document.getElementById('booking-dashboard');
const refreshBookingsButton = document.getElementById('refresh-bookings');

let isRegisterMode = false;
let selectedSlotId = null;

function setMessage(text, tone = 'info') {
  bookingMessage.textContent = text;
  bookingMessage.style.color = tone === 'error' ? '#a63939' : '#2f7d7e';
}

async function loadServices() {
  const response = await fetch('/api/services');
  const services = await response.json();
  serviceSelect.innerHTML = services.map((service) => `<option value="${service.id}">${service.name}</option>`).join('');
}

async function loadSlots() {
  const response = await fetch('/api/slots');
  const slotsByDate = await response.json();
  slotList.innerHTML = slotsByDate.map((day) => `
    <div class="slot-card">
      <strong>${day.date}</strong>
      ${day.slots.map((slot) => `
        <div>
          <input type="radio" name="slot" value="${slot.id}" id="slot-${slot.id}" ${slot.bookedCount >= slot.capacity ? 'disabled' : ''} />
          <label for="slot-${slot.id}">${slot.slotTime} ${slot.bookedCount >= slot.capacity ? '(Booked Out)' : '(Open)'}</label>
        </div>`).join('')}
    </div>
  `).join('');

  slotList.querySelectorAll('input[name="slot"]').forEach((input) => {
    input.addEventListener('change', () => {
      selectedSlotId = Number(input.value);
    });
  });
}

async function loadBookings() {
  const response = await fetch('/api/bookings');
  if (!response.ok) {
    bookingDashboard.innerHTML = '<p>Please sign in to view your bookings.</p>';
    return;
  }
  const bookings = await response.json();
  if (!bookings.length) {
    bookingDashboard.innerHTML = '<p>No bookings yet.</p>';
    return;
  }
  bookingDashboard.innerHTML = bookings.map((booking) => `
    <div class="booking-item">
      <strong>${booking.serviceName}</strong>
      <div>${booking.slotDate} at ${booking.slotTime}</div>
      <div>Payment: ${booking.paymentMethod}</div>
      <div>Status: ${booking.status}</div>
    </div>
  `).join('');
}

async function fetchCurrentUser() {
  try {
    const response = await fetch('/api/auth/me');
    if (!response.ok) {
      authStatus.textContent = 'Please sign in';
      return;
    }
    const data = await response.json();
    authStatus.textContent = `Signed in as ${data.user.username}`;
    await loadBookings();
  } catch (error) {
    authStatus.textContent = 'Please sign in';
  }
}

authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  const endpoint = isRegisterMode ? '/api/auth/register' : '/api/auth/login';

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });

  const result = await response.json();
  if (!response.ok) {
    setMessage(result.error, 'error');
    return;
  }

  setMessage(isRegisterMode ? 'Account created. Please book your slot.' : 'Signed in successfully.');
  await fetchCurrentUser();
  authForm.reset();
});

toggleAuth.addEventListener('click', () => {
  isRegisterMode = !isRegisterMode;
  toggleAuth.textContent = isRegisterMode ? 'Back to login' : 'Create account';
  setMessage(isRegisterMode ? 'Create a new account to continue.' : 'Use your existing account to sign in.');
});

bookingForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!selectedSlotId) {
    setMessage('Please select an open slot.', 'error');
    return;
  }

  const paymentMethod = document.getElementById('payment-select').value;
  const response = await fetch('/api/bookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ slotId: selectedSlotId, serviceId: serviceSelect.value, paymentMethod })
  });
  const result = await response.json();
  if (!response.ok) {
    setMessage(result.error, 'error');
    return;
  }

  setMessage(`Reservation confirmed for ${result.booking.serviceName}.`);
  await loadSlots();
  await loadBookings();
});

refreshBookingsButton.addEventListener('click', async () => {
  await loadBookings();
});

(async function init() {
  await loadServices();
  await loadSlots();
  await fetchCurrentUser();
})();
