const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const dbDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dbDir, { recursive: true });

const dbPath = path.join(dbDir, 'kineticage.db');
const db = new DatabaseSync(dbPath);

db.exec('PRAGMA journal_mode = WAL');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password, storedPassword) {
  const [salt, hash] = storedPassword.split(':');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return hash === derived;
}

function formatDate(date) {
  const offset = date.getTimezoneOffset();
  const corrected = new Date(date.getTime() - offset * 60 * 1000);
  return corrected.toISOString().slice(0, 10);
}

function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slot_date TEXT NOT NULL,
      slot_time TEXT NOT NULL,
      capacity INTEGER NOT NULL DEFAULT 1,
      booked_count INTEGER NOT NULL DEFAULT 0,
      UNIQUE(slot_date, slot_time)
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      slot_id INTEGER NOT NULL,
      service_id INTEGER NOT NULL,
      payment_method TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'confirmed',
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (slot_id) REFERENCES slots(id),
      FOREIGN KEY (service_id) REFERENCES services(id)
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_active_bookings
    ON bookings(slot_id, status)
    WHERE status = 'confirmed';
  `);

  const serviceCount = db.prepare('SELECT COUNT(*) AS count FROM services').get().count;
  if (serviceCount === 0) {
    db.prepare(`
      INSERT INTO services (name, description) VALUES
      ('Senior Mobility Assessment', 'A guided wellness assessment focused on strength, balance, and comfort.'),
      ('Chair Yoga', 'Gentle seated movement for flexibility and circulation.'),
      ('Balance & Fall Prevention', 'Structured balance exercises designed to build confidence and stability.'),
      ('Home Wellness Check', 'A practical support visit covering mobility goals and daily routines.')
    `).run();
  }

  const slotCount = db.prepare('SELECT COUNT(*) AS count FROM slots').get().count;
  if (slotCount === 0) {
    const slotTimes = ['09:00', '10:30', '13:00', '14:30'];
    for (let offset = 0; offset < 3; offset += 1) {
      const date = new Date();
      date.setDate(date.getDate() + offset);
      const slotDate = formatDate(date);
      slotTimes.forEach((slotTime) => {
        db.prepare('INSERT INTO slots (slot_date, slot_time, capacity, booked_count) VALUES (?, ?, ?, 0)').run(slotDate, slotTime, 1);
      });
    }
  }
}

function registerUser(username, password) {
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) {
    throw new Error('A user with that username already exists.');
  }

  const insert = db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)');
  const result = insert.run(username, hashPassword(password));
  return { id: result.lastInsertRowid, username };
}

function authenticateUser(username, password) {
  const user = db.prepare('SELECT id, username, password_hash FROM users WHERE username = ?').get(username);
  if (!user) {
    throw new Error('Unknown username.');
  }

  if (!verifyPassword(password, user.password_hash)) {
    throw new Error('Incorrect password.');
  }

  return { id: user.id, username: user.username };
}

function listServices() {
  return db.prepare('SELECT id, name, description FROM services ORDER BY id').all();
}

function listSlots() {
  const rows = db.prepare(`
    SELECT id, slot_date AS slotDate, slot_time AS slotTime, capacity, booked_count AS bookedCount
    FROM slots
    WHERE slot_date >= ?
    ORDER BY slot_date, slot_time
  `).all(formatDate(new Date()));

  const grouped = rows.reduce((acc, slot) => {
    if (!acc[slot.slotDate]) {
      acc[slot.slotDate] = [];
    }
    acc[slot.slotDate].push(slot);
    return acc;
  }, {});

  return Object.entries(grouped).slice(0, 3).map(([date, slots]) => ({
    date,
    slots
  }));
}

function createReservation(userId, slotId, serviceId, paymentMethod) {
  const service = db.prepare('SELECT id, name FROM services WHERE id = ?').get(serviceId);
  if (!service) {
    throw new Error('Selected service is no longer available.');
  }

  db.exec('BEGIN IMMEDIATE');
  try {
    const slot = db.prepare('SELECT id, capacity, booked_count, slot_date AS slotDate, slot_time AS slotTime FROM slots WHERE id = ?').get(slotId);
    if (!slot) {
      throw new Error('Selected slot no longer exists.');
    }

    const existing = db.prepare('SELECT id FROM bookings WHERE slot_id = ? AND status = ?').get(slotId, 'confirmed');
    if (existing) {
      throw new Error('That slot has already been reserved.');
    }

    if (slot.booked_count >= slot.capacity) {
      throw new Error('That slot has already been reserved.');
    }

    db.prepare('UPDATE slots SET booked_count = booked_count + 1 WHERE id = ?').run(slotId);
    const result = db.prepare(`
      INSERT INTO bookings (user_id, slot_id, service_id, payment_method, status, created_at)
      VALUES (?, ?, ?, ?, 'confirmed', ?)
    `).run(userId, slotId, serviceId, paymentMethod, new Date().toISOString());

    db.exec('COMMIT');

    return {
      id: result.lastInsertRowid,
      serviceName: service.name,
      slotDate: slot.slotDate,
      slotTime: slot.slotTime,
      paymentMethod,
      status: 'confirmed'
    };
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

function listBookingsForUser(userId) {
  const rows = db.prepare(`
    SELECT b.id, b.payment_method AS paymentMethod, b.status, b.created_at AS createdAt,
           s.name AS serviceName, sl.slot_date AS slotDate, sl.slot_time AS slotTime
    FROM bookings b
    JOIN services s ON s.id = b.service_id
    JOIN slots sl ON sl.id = b.slot_id
    WHERE b.user_id = ?
    ORDER BY sl.slot_date, sl.slot_time
  `).all(userId);

  return rows.map((booking) => ({
    ...booking,
    isUpcoming: new Date(`${booking.slotDate}T${booking.slotTime}`).getTime() >= Date.now()
  }));
}

function cancelBooking(userId, bookingId) {
  const booking = db.prepare('SELECT id, slot_id FROM bookings WHERE id = ? AND user_id = ?').get(bookingId, userId);
  if (!booking) {
    throw new Error('Booking not found.');
  }

  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run('cancelled', bookingId);
    db.prepare('UPDATE slots SET booked_count = booked_count - 1 WHERE id = ?').run(booking.slot_id);
    db.exec('COMMIT');
    return { id: bookingId, status: 'cancelled' };
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

function getCurrentUser(userId) {
  if (!userId) {
    return null;
  }

  const user = db.prepare('SELECT id, username FROM users WHERE id = ?').get(userId);
  return user ? { id: user.id, username: user.username } : null;
}

module.exports = {
  initializeDatabase,
  registerUser,
  authenticateUser,
  listServices,
  listSlots,
  createReservation,
  listBookingsForUser,
  cancelBooking,
  getCurrentUser
};
