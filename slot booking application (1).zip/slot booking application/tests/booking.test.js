const test = require('node:test');
const assert = require('node:assert/strict');
const { initializeDatabase, registerUser, authenticateUser, createReservation, listBookingsForUser, cancelBooking } = require('../src/bookingService');

test('creates and cancels a reservation without double booking', () => {
  initializeDatabase();
  const username = `tester-${Date.now()}`;
  const user = registerUser(username, 'secret123');
  const services = require('../src/bookingService').listServices();
  const slots = require('../src/bookingService').listSlots();
  const firstSlot = slots[0]?.slots[0];
  const service = services[0];

  assert.ok(user.id, 'user id should be present');
  assert.ok(firstSlot, 'at least one slot should be available');
  assert.ok(service, 'a service should be available');

  const booking = createReservation(user.id, firstSlot.id, service.id, 'Prepaid');
  assert.equal(booking.status, 'confirmed');

  const bookings = listBookingsForUser(user.id);
  assert.equal(bookings.length, 1);

  const cancelled = cancelBooking(user.id, booking.id);
  assert.equal(cancelled.status, 'cancelled');

  const remaining = listBookingsForUser(user.id);
  assert.equal(remaining.length, 1);
  assert.equal(remaining[0].status, 'cancelled');

  assert.doesNotThrow(() => authenticateUser(username, 'secret123'));
});
